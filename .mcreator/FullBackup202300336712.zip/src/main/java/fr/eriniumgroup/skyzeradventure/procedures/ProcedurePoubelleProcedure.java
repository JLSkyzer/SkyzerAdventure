package fr.eriniumgroup.skyzeradventure.procedures;

public class ProcedurePoubelleProcedure {
	public static void execute() {
	}
}
